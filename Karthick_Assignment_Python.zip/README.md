README.md
1. Why is LibraryItem abstract, and what happens if DVD forgets to write late_fee()?

LibraryItem is abstract because it provides a common structure for all library items and cannot be instantiated directly. If DVD does not implement late_fee(), Python raises a TypeError when creating its object.

2. What happens when you read item.__available from outside the class, and why do we use is_available() instead?

Accessing item.__available from outside the class raises an AttributeError because it is a private attribute. We use is_available() to access the value safely and maintain encapsulation.

3. What is the difference between LibraryItem.total_items and self.title?

LibraryItem.total_items is a class variable shared by all objects, while self.title is an instance variable that stores the title of an individual library item.

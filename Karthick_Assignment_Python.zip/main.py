# main.py
from models import Book, Magazine, DVD, Member
book = Book("Python 101", 1, "A. Rao")
magazine = Magazine("The New Yorker", 2, 1)
dvd = DVD("The Matrix", 3, 120)
alice = Member("Alice", 101)
bob = Member("Bob", 102, max_items=1)
# 1. Borrowing with error handling
try:
    alice.borrow(book)
    print("Alice borrowed:", book.describe())
    bob.borrow(book)  # should fail: already borrowed
except ValueError as e:
    print("Could not borrow:", e)
# 2. trigger the borrow-limit error and the not-borrowed error, catching each
try:
    bob.borrow(magazine)  # Bob's max_items is 1, this succeeds
    bob.borrow(dvd)       # should fail: borrow limit
except ValueError as e:
    print("Could not borrow:", e)
try:
    bob.return_item(book)  # should fail: Bob never borrowed this book
except ValueError as e:
    print("Could not return:", e)
# 3. Polymorphism: one loop, no type checks
items = [book, magazine, dvd]
for item in items:
    print(item.describe(), "-> late fee for 3 days: Rs", item.late_fee(3))
# 4. Class attribute shared by all objects
print("Total items created:", Book.total_items)
